import React from 'react';
import { BrowserRouter as Router, Link, Switch, Route } from 'react-router-dom';
import MainSite from './mainsite';
import LoginComponent from './LoginComponent';
import RegisterComponent from './RegisterComponent';

function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/login">
            <LoginComponent />
          </Route>
          <Route path="/register">
            <RegisterComponent />
          </Route>
          <Route path="/">
            <MainSite />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
