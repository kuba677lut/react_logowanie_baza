import React from 'react';
import './App.css';
import { Link } from 'react-router-dom';

function MainSite() {
  return (
    <div>

      <header>
        <h1>Witamy w restauracji "Wszystkie Smaki"</h1>
        <section id="prz">
                <Link to="/login">
                    <button id='nav'>Login</button>
                </Link>
                <Link to="/register">
                    <button id='nav'>Register</button>
                </Link>
            </section>
      </header>

      <main>
        <section id="lewy">
          <img src="menu.jpg" alt="Nasze danie" />
        </section>

        <section id="prawy">
        
          <h4>U nas dobrze zjesz!</h4>
          <ol>
            <li>Obiady od 40 zł</li>
            <li>Przekąski od 10 zł</li>
            <li>Kolacje od 20 zł</li>
          </ol>
        </section>

        <section id="dolny">
          <h2>Zarezerwuj stolik on-line</h2>

          <form>

            <label>
              Data (format rrrr-mm-dd):<br/>
              <input name="data" /><br/>
            </label>

            <label>
              Ile osób?<br/>
              <input type="number" name="ilosc" /><br/>
            </label>

            <label>
              Twój numer telefonu:<br/>
              <input name="telefon" /><br/>
            </label>

            <label>
              <input type="checkbox" name="check" />
              Zgadzam się na przetwarzanie moich danych osobowych<br/>
            </label>

            <button id='str' type="reset">WYCZYŚĆ</button>
            <button id='str' name="rezerwuj">REZERWUJ</button>

          </form>

        </section>

      <footer>
          Stronę internetową opracował: <i>Jakub Stepaniuk</i>
        </footer>
      </main>
    </div>
  );
}

export default MainSite;
